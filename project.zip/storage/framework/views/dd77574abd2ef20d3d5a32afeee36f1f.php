<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\HP\TA_Absensi\absensi-magang\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>